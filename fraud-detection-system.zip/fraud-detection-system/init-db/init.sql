-- Base de datos relacional: cuentas y transacciones
CREATE TABLE IF NOT EXISTS accounts (
    id SERIAL PRIMARY KEY,
    owner_name VARCHAR(150) NOT NULL,
    account_number VARCHAR(30) UNIQUE NOT NULL,
    balance NUMERIC(15,2) NOT NULL DEFAULT 0,
    country VARCHAR(60),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS transactions (
    id SERIAL PRIMARY KEY,
    transaction_uuid VARCHAR(64) UNIQUE NOT NULL,
    account_id INTEGER REFERENCES accounts(id),
    amount NUMERIC(15,2) NOT NULL,
    merchant VARCHAR(150),
    merchant_country VARCHAR(60),
    channel VARCHAR(30), -- ONLINE, ATM, POS, TRANSFER
    status VARCHAR(20) DEFAULT 'PENDING', -- PENDING, APPROVED, FLAGGED, REJECTED
    risk_score DOUBLE PRECISION,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_transactions_account ON transactions(account_id);
CREATE INDEX IF NOT EXISTS idx_transactions_status ON transactions(status);

-- Datos de prueba
INSERT INTO accounts (owner_name, account_number, balance, country) VALUES
('Ana Torres', 'ACC-0001', 5000.00, 'AR'),
('Luis Gómez', 'ACC-0002', 12000.00, 'AR'),
('María Ruiz', 'ACC-0003', 800.00, 'CL'),
('Carlos Díaz', 'ACC-0004', 25000.00, 'AR')
ON CONFLICT DO NOTHING;
